package com.usach.msprestamos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPrestamosApplicationTests {

	@Test
	void contextLoads() {
	}

}

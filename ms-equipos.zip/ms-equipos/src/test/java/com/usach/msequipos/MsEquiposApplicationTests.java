package com.usach.msequipos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsEquiposApplicationTests {

	@Test
	void contextLoads() {
	}

}
